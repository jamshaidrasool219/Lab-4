# Lab 04: Priority Queue (C++)

Data Structures lab – Priority Queue implemented with a singly linked list.
A smaller priority number means a higher priority. Requests with the same priority are served in arrival order.

**Student:** Muhammad Jamshaid Rasool (2025-ADP-AI-10) – IMLCSAI, UET Lahore

## Files

| File | Description |
|------|-------------|
| `PartA_LibraryPriorityQueue.cpp` | Library Urgent Book Request System as a menu-driven console app |
| `PartB_WhatsAppMessagePriorityQueue.cpp` | Individual project: priority queue for WhatsApp Auto-Reply AI Agent messages |

## Part A – Library Book Request System
Menu: Add Request, Process Highest Priority, Display All, Check Queue Status, Exit.
Priorities: 1 = Exam/Urgent, 2 = Assignment/Project, 3 = Normal reading.

## Part B – WhatsApp Auto-Reply Agent
Incoming customer messages are queued by urgency:
1 = Urgent (payment/complaint), 2 = Important (order status/inquiry), 3 = Normal (general/greetings).
The AI agent always replies to the most urgent message first.

## Build and run
```
g++ -std=c++11 PartA_LibraryPriorityQueue.cpp -o partA && ./partA
g++ -std=c++11 PartB_WhatsAppMessagePriorityQueue.cpp -o partB && ./partB
```
